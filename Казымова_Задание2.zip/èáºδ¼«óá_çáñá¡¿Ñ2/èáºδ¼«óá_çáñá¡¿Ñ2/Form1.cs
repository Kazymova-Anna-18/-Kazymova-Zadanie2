﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Казымова_Задание2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            double sred = 0;
            double max = 0;
            double min = 10;
            Random rnd = new Random();
            int sudi = Convert.ToInt32(textBox1.Text);//кол-во судей
            int figuristki = Convert.ToInt32(textBox2.Text);//кол-во фигуристок
            double[,] ozenka = new double[figuristki, sudi];
            dataGridView1.RowCount = figuristki ;//ввод количества строк
            dataGridView1.ColumnCount = sudi;//ввод количества столбцов
            if (sudi <= 10 & sudi >= 3) 
            {
                
                    
                for (int i = 0; i < figuristki ; i++)
                {
                    max = 0;
                    min = 10;
                    sred = 0;
                    dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                    for (int j = 0; j < sudi; j++)
                    {
                        dataGridView1.Columns[j].HeaderCell.Value = (j + 1).ToString();
                        ozenka[i, j] = rnd.Next(0, 10);// вывод оценки
                        dataGridView1[j, i].Value = Math.Round(ozenka[i, j], 1).ToString();
                        if (max < ozenka[i, j])
                        {
                           max = ozenka[i, j];//Максимальная оценка
                        }
                        if (min > ozenka[i, j])
                        {
                           min = ozenka[i, j];//Минимальная оценка
                        }
                        sred += ozenka[i, j];//Сумма всех цифр
                    }
                
                 double bez = sred - (min + max);
                 bez /= (sudi - 2);
                    listBox1.Items.Add(String.Format("Фигуристка под номером: " + (i + 1) + " получила столько балов: " + Math.Round(bez,1)));
                }
                
            }
            else
            {
                MessageBox.Show("Ошибка! Вы ввели либо слишком много, либо слишком мало судей! Их должно быть не больше 10 и не меньше 3! Пожалуйста проверьте!");//Ошибка по каличеству судей
            }
            
        }
    }
}
